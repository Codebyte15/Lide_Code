import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, scrolledtext
import subprocess, os

current_file = None
is_saved = True
zoom = 12
appdata = os.getenv("APPDATA")
settings_path = os.path.join(appdata, "LIDE", "Settings.ini")
file_name = os.path.join(appdata, "LIDE", "saved_filename.ini")
os.makedirs(os.path.dirname(file_name), exist_ok=True)

root = tk.Tk()
root.iconbitmap("icon/lide.ico")
root.state("zoomed")
root.minsize(500, 500)
root.maxsize(5000, 5000)

BLOCK_KEYWORDS = {
    ".py":  ('def', 'class', 'if', 'elif', 'else', 'for', 'while', 'try', 'except', 'finally', 'with', 'async'),
    ".c":   ('if', 'else', 'for', 'while', 'do', 'switch', 'case', 'struct', 'union', 'enum', 'goto'),
    ".cpp": ('if', 'else', 'for', 'while', 'do', 'switch', 'case', 'struct', 'union', 'enum', 'class', 'try', 'catch'),
    ".java":('if', 'else', 'for', 'while', 'do', 'switch', 'case', 'try', 'catch', 'finally', 'class', 'interface', 'enum'),
    ".js":  ('if', 'else', 'for', 'while', 'do', 'switch', 'case', 'function', 'class', 'try', 'catch', 'finally')
}

color = "white"
fg_color = "black"
bg_color = "SystemButtonFace"
Colorbutton = "Dark Mode"

if os.path.exists(file_name):
    with open(file_name, "r") as f:
        last_file = f.read().strip()
        if last_file and os.path.exists(last_file):
            current_file = last_file
        
            
class IDE:
    editor = None
    preview_editor = None
    line_count_label = None
    preview_label = None
    new_btn = None
    open_btn = None
    preview_btn = None
    Color_btn = None

    @staticmethod
    def main():
        global color, fg_color, Colorbutton
        if os.path.exists(settings_path):
            with open(settings_path, "r") as f:
                Color_mode = f.read().strip()
                IDE.Color_Mode(Color_mode)
        
        # Menu
        menubar = tk.Menu(root)
        root.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New", command=IDE.new_file)
        file_menu.add_command(label="Open", command=IDE.open_file)
        file_menu.add_command(label="Save", command=IDE.save_file)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=IDE.exit_app)
        menubar.add_cascade(label="File", menu=file_menu)

        run_menu = tk.Menu(menubar, tearoff=0)
        run_menu.add_command(label="Python File (F5)", command=lambda: IDE.run_app("Python"))
        run_menu.add_command(label="C File (F6)", command=lambda: IDE.run_app("C"))
        run_menu.add_command(label="C++ File (F7)", command=lambda: IDE.run_app("CPP"))
        run_menu.add_command(label="Java File (F8)", command=lambda: IDE.run_app("Java"))
        menubar.add_cascade(label="Run", menu=run_menu)

        IDE.editor = scrolledtext.ScrolledText(
            root, width=146, height=41, font=("Consolas", zoom),
            bg=color, fg=fg_color, bd=10, insertbackground=fg_color, wrap=tk.NONE
        )
        IDE.editor.place(x=240, y=10)

        IDE.new_btn = tk.Button(root, text="New File", font=("Arial", 10), bd=5, width=8, height=1, command=IDE.new_file)
        IDE.new_btn.place(x=20, y=8)

        IDE.open_btn = tk.Button(root, text="Open File", font=("Arial", 10), bd=5, width=8, height=1, command=IDE.open_file)
        IDE.open_btn.place(x=120, y=8)

        IDE.preview_btn = tk.Button(root, text="Preview", font=("Arial", 10), bd=5, width=8, height=1, command=IDE.preview)
        IDE.preview_btn.place(x=120, y=50)

        IDE.Color_btn = tk.Button(root, text="DarkMode", font=("Arial", 10), bd=5, width=8, height=1, command=IDE.Dark_Mode)
        IDE.Color_btn.place(x=20, y=50)

        IDE.line_count_label = tk.Label(root, text="No of lines written = 0", font=("Arial", 15), bg=bg_color, fg=fg_color)
        IDE.line_count_label.place(x=15, y=100)
        
        for btn in [IDE.new_btn, IDE.open_btn, IDE.preview_btn, IDE.Color_btn]:
            btn.config(bg=bg_color, fg=fg_color, activebackground=color, activeforeground=fg_color)
            
        if current_file:
            with open(current_file, "r") as f:
                IDE.editor.insert("1.0", f.read())
            IDE.update_line_count()
            update_title()
    @staticmethod
    def on_key_release(event=None):
        IDE.update_line_count()
        IDE.update_preview_content()
        
    @staticmethod
    def preview():
        if IDE.preview_editor and IDE.preview_editor.winfo_ismapped():
            IDE.preview_editor.place_forget()
            IDE.preview_editor = None
            if IDE.preview_label:
                IDE.preview_label.place_forget()
                IDE.preview_label = None
            return

        IDE.preview_editor = tk.Text(root, width=25, height=39, bd=10, bg=color, fg=fg_color)
        IDE.preview_editor.place(x=10, y=165)
        IDE.preview_editor.config(state="disabled")

        IDE.preview_label = tk.Label(root, text="Preview window is ON", font=("Arial", 12, "bold"), bg=bg_color, fg=fg_color)
        IDE.preview_label.place(x=15, y=135)

        IDE.update_preview_content()

    @staticmethod
    def update_preview_content():
        if IDE.preview_editor:
            content = IDE.editor.get("1.0", "end-1c")
            IDE.preview_editor.config(state="normal")
            IDE.preview_editor.delete("1.0", tk.END)
            IDE.preview_editor.insert("1.0", content)
            IDE.preview_editor.config(state="disabled")
            IDE.update_line_count(content)

    @staticmethod
    def update_line_count(content=None):
        if content is None:
            content = IDE.editor.get("1.0", "end-1c")
        lines = [line for line in content.split("\n") if line.strip()]
        IDE.line_count_label.config(text=f"No of lines written = {len(lines)}")

    @staticmethod
    def new_file():
        global current_file, is_saved
        name = simpledialog.askstring("Input", "Enter file name with extension:")
        if not name:
            return
        folder = filedialog.askdirectory(title="Select folder to save file")
        if not folder:
            return
        current_file = os.path.join(folder, name)
        open(current_file, "w").close()
        IDE.editor.delete("1.0", tk.END)
        is_saved = True
        with open(file_name, "w") as f:
            f.write(current_file)
        update_title()
        IDE.update_preview_content()

    @staticmethod
    def open_file():
        global current_file, is_saved
        path = filedialog.askopenfilename(title="Select a file", filetypes=(("All files", "*.*"),))
        if not path:
            return
        current_file = path
        with open(current_file, "r") as f:
            IDE.editor.delete("1.0", tk.END)
            IDE.editor.insert("1.0", f.read())
        is_saved = True
        with open(file_name, "w") as f:
            f.write(current_file)
        IDE.update_line_count()
        update_title()

    @staticmethod
    def save_file(event=None):
        global is_saved
        if os.path.exists(settings_path):
            with open(settings_path, "w") as f:
                f.write(Colorbutton)
        if not current_file:
            messagebox.showinfo("Save File", "First create or open a file")
            return
        with open(current_file, "w") as f:
            f.write(IDE.editor.get("1.0", "end-1c"))
        is_saved = True
        with open(file_name, "w") as f:
            f.write(current_file)
        update_title()
        return "break"

    @staticmethod
    def run_app(filetype):
        global current_file
        if not current_file:
            messagebox.showwarning("No File", "Create or open a file first!")
            return

        ext = os.path.splitext(current_file)[1].lower()

        if filetype == "Python":
            cmd = f'python "{current_file}" & pause & exit'
            subprocess.Popen(f'start cmd /k "{cmd}"', shell=True)
            return

        if filetype == "C":
            exe = os.path.splitext(current_file)[0] + ".exe"
            cmd = f'gcc "{current_file}" -o "{exe}" && "{exe}" & pause & exit'
            subprocess.Popen(f'start cmd /k "{cmd}"', shell=True)
            return

        if filetype == "CPP":
            exe = os.path.splitext(current_file)[0] + ".exe"
            cmd = f'g++ "{current_file}" -o "{exe}" && "{exe}" & pause & exit'
            subprocess.Popen(f'start cmd /k "{cmd}"', shell=True)
            return

        if filetype == "Java":
            name = os.path.splitext(os.path.basename(current_file))[0]
            path = os.path.dirname(current_file) or '.'
            cmd = f'cd /d "{path}" && javac "{current_file}" && java {name} & pause & exit'
            subprocess.Popen(f'start cmd /k "{cmd}"', shell=True)
            return

    @staticmethod
    def exit_app():
        if messagebox.askyesno("Exit", "Do you want to exit? Unsaved changes will be lost."):
            root.destroy()

    @staticmethod
    def Dark_Mode():
        global color, fg_color, bg_color, Colorbutton
        if color == "white":
            color = "#252526"
            fg_color = "#D4D4D4"
            bg_color = "#1E1E1E"
            Colorbutton = "Dark Mode"
        else:
            color = "white"
            fg_color = "black"
            bg_color = "SystemButtonFace"
            Colorbutton = "Default Mode"
            
        with open(settings_path, "w") as f:
            f.write(Colorbutton)
                
        IDE.editor.config(bg=color, fg=fg_color, insertbackground=fg_color)
        for btn in [IDE.new_btn, IDE.open_btn, IDE.preview_btn, IDE.Color_btn]:
            btn.config(bg=bg_color, fg=fg_color, activebackground=color, activeforeground=fg_color)
        root.configure(bg=bg_color)
        if IDE.preview_editor:
            IDE.preview_editor.config(bg=color, fg=fg_color)
        if IDE.line_count_label:
            IDE.line_count_label.config(bg=bg_color, fg=fg_color)
        if IDE.preview_label:
            IDE.preview_label.config(bg=bg_color, fg=fg_color)
            
    @staticmethod
    def Color_Mode(mode):
        global color, fg_color, bg_color, Colorbutton
        if mode.lower() == "dark mode":
            color, fg_color, bg_color, Colorbutton = "#252526", "#D4D4D4", "#1E1E1E", "Dark Mode"
        else:
            color, fg_color, bg_color, Colorbutton = "white", "black", "SystemButtonFace", "Default Mode"
        if IDE.editor:
            IDE.editor.config(bg=color, fg=fg_color, insertbackground=fg_color)
        root.configure(bg=bg_color)
        if IDE.preview_editor:
            IDE.preview_editor.config(bg=color, fg=fg_color, insertbackground=fg_color)
        if IDE.line_count_label:
            IDE.line_count_label.config(bg=bg_color, fg=fg_color)

def update_title():
    global current_file, is_saved
    name = current_file if current_file else "Untitled"
    if not is_saved:
        name = "*" + name
    root.title(f"{name} - LIDE")

def on_text_change(event=None):
    global is_saved
    if IDE.editor.edit_modified():
        is_saved = False
        update_title()
        IDE.editor.edit_modified(False)

def on_close():
    result = messagebox.askyesnocancel("Confirm Exit", "Do you want to save before exiting?\n Unsaved changes will be deleted")
    if result is True:
        IDE.save_file()
        root.destroy()
    elif result is False:
        root.destroy()
        
def auto_indent(event=None):
    # Get the current file extension
    ext = os.path.splitext(current_file or "")[1].lower()
    keywords = BLOCK_KEYWORDS.get(ext, BLOCK_KEYWORDS[".py"])  # default to Python if unknown

    # Get current line
    index = IDE.editor.index("insert")
    line_start = f"{index.split('.')[0]}.0"
    current_line = IDE.editor.get(line_start, f"{line_start} lineend")

    # Count leading spaces
    leading_spaces = len(current_line) - len(current_line.lstrip(' '))

    # Check if the current line ends with a block keyword
    increase_indent = False
    stripped = current_line.strip()

    for kw in keywords:
        # For Python, line must end with ':', for others, assume '{' or keyword triggers
        if ext == ".py":
            if stripped.startswith(kw) and stripped.endswith(':'):
                increase_indent = True
                break
        else:
            if stripped.startswith(kw):
                increase_indent = True
                break

    # Insert newline and indentation
    IDE.editor.insert("insert", "\n")
    spaces = ' ' * leading_spaces
    if increase_indent:
        spaces += ' ' * 4  # Add extra 4 spaces for block
    IDE.editor.insert("insert", spaces)

    return "break"

root.bind("<Control-s>", IDE.save_file)
root.bind("<F5>", lambda e: IDE.run_app("Python"))
root.bind("<F6>", lambda e: IDE.run_app("C"))
root.bind("<F7>", lambda e: IDE.run_app("CPP"))
root.bind("<F8>", lambda e: IDE.run_app("Java"))

IDE.main()
IDE.preview()

IDE.editor.bind("<<Modified>>", on_text_change)
IDE.editor.bind("<KeyRelease>", IDE.on_key_release)
IDE.editor.bind("<Return>", auto_indent)
root.protocol("WM_DELETE_WINDOW", on_close)
root.mainloop()
